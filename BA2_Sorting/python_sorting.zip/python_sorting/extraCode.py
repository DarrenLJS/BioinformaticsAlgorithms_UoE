import time # a library needed fo timing functions

#import the scripts
from bubbleSort import bubbleSort
from quickSort import quickSort
from selectionSort import selectionSort


#This reads a file...
def readFile(fle):
    f = open(fle, 'r')
    x = f.readlines()
    f.close()
    results = [int(i) for i in x]
    return results


#This can be passed a file to sort and the sort algorithm
def testPerformance(filename,algorithm):
    arr2 = readFile(filename)
    start = time.time()
    algorithm(arr2)
    elapsed =time.time()-start

    #how to print the elapsed time
    print("")
    print("Sorted big container: %s secs" % elapsed)
    for i in range(10):
           print(arr2[i],end=" ")
    print("")
    return elapsed 

#driver code example
print("\nSorting using \"bubbleSort\" and \"random5000.txt\"")
testPerformance("random5000.txt",bubbleSort)
